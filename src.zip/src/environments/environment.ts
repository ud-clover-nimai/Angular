// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
domain:'http://136.232.244.190:8081'   /// Dev server
//domain:'http://203.115.123.93:8080'  /// Testing  server
//domain:'http://203.115.123.93:9090'  /// Client port
//domain:'http://10.1.1.86:8080'  /// prod port
//domain:'http://nimai-pilot-lb-468660897.me-south-1.elb.amazonaws.com'  /// production port
// domain:'http://localhost:8080'
};


/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
