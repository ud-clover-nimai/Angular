export const environment = {
  production: true,
//domain:'http://136.232.244.190:8081'
 domain:'http://203.115.123.93:8080'
 //domain:'http://203.115.123.93:9090'
 //domain:'http://nimai-pilot-lb-468660897.me-south-1.elb.amazonaws.com'  /// production port

};
