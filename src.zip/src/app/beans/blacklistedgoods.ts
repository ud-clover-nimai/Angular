export interface BlackListedGoods {
    goods_ID: number;
    goodsMId: number;
    blackListGoods: string;
}