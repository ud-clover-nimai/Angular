

export interface OwnerDetail {
    ownerID: number;
    ownerFirstName: string;
    ownerLastName: string;
    designation: string;
}