import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-active-transaction',
  templateUrl: './active-transaction.component.html',
  styleUrls: ['./active-transaction.component.css']
})
export class ActiveTransactionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
